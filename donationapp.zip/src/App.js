import React from 'react'
import './App.css';
import DonateForm from './donation/DonateForm'
import AddSlide from './NewsApplication/ADS/AddSlide';
import WebPosts from './NewsApplication/ADS/WebPosts';
import NewsApp from './NewsApplication/NewsApp';

function App() {
  return (
    <div className="p-4">
      <h1 className='text-center' >Post Website to ADS</h1>
      <AddSlide />
      <WebPosts />
      {/* <DonateForm /> */}
      {/* <NewsApp /> */}
    </div>
  )
}

export default App
