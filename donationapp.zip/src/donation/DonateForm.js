import React from 'react'
import { exportComponentAsJPEG, exportComponentAsPDF, exportComponentAsPNG } from 'react-component-export-image';
import { useEffect, useState, useRef } from "react"
import { v4 as uuidv4 } from 'uuid';
import Donerlist from './Donerlist';



function DonateForm() {
  const componentRef = useRef();
  const ComponentToPrint = React.forwardRef((props, ref) => (
    <div ref={ref}>
      <Donerlist List={DonationList} />
    </div>
  ));
  
  const [DonationList, setDonationList] = useState([]);
  const [userInput, setUserInput] = useState({
    name: "", amount: "", mob: "", email: ""
  });
  const [ID, setID] = useState();

  const handleInputs = (e) => {

    let name = e.target.name;
    let value = e.target.value;
    setUserInput({ ...userInput, [name]: value });
  }

  const submitVal = (e) => {
    e.preventDefault();
    //console.warn(userInput);
    setDonationList([...DonationList, userInput]);
    console.log("Donation succesfull");
    setUserInput({
      name: "", amount: "", mob: "", email: ""
    });
  }
  const GenrateId = (e) => {
    e.preventDefault();
    if (ID === undefined) {
      setID(uuidv4())
    } else {
      setID(uuidv4())
      console.log("Id is sucessfully genrated: " + ID);
    }
  }
  //console.log(DonationList);
  return (
    <>
      <div className='container'>
        <button className='btn btn-info' onClick={GenrateId}>Genrate Id</button>
        <h2>Please donate !</h2>
        <form onSubmit={submitVal}>
          <div className='row'>
            <div className="form-group col-lg-3 ">
              <label htmlFor="exampleInputName">Name</label>
              <input
                onChange={handleInputs}
                name="name"
                value={userInput.name}
                type="text"
                className="form-control"
                placeholder="Enter Name" />
            </div>
            <div className="form-group col-lg-3">
              <label htmlFor="exampleInputEmail1">Contact No. </label>
              <input
                onChange={handleInputs}
                name="mob"
                value={userInput.mob}
                type="number"
                className="form-control"
                placeholder="Enter Contact No." />
            </div>
            <div className="form-group col-lg-3">
              <label htmlFor="exampleInputEmail">Email</label>
              <input
                onChange={handleInputs}
                name="email"
                value={userInput.email}
                type="email"
                className="form-control"
                placeholder="Email" />
            </div>
            <div className="form-group col-lg-3">
              <label htmlFor="exampleAmount">Amount</label>
              <input
                onChange={handleInputs}
                name="amount"
                value={userInput.amount}
                type="number"
                className="form-control"
                placeholder="Amount" />
            </div>
            <br></br>
            <button type="submit" className="btn btn-primary">Donate Now</button>
          </div>
        </form>
      </div>

      <Donerlist List={DonationList} />
      <ComponentToPrint ref={componentRef} />
      <button onClick={() => exportComponentAsJPEG(componentRef)}>
        Export As JPEG
      </button>
      <button onClick={() => exportComponentAsPDF(componentRef)}>
        Export As PDF
      </button>
      <button onClick={() => exportComponentAsPNG(componentRef)}>
        Export As PNG
      </button>
    </>
  )
}

export default DonateForm