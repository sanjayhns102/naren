import React,{useState,useEffect} from 'react'



function AddSlide() {

  const [userInput, setUserInput] = useState({
    Project: "", Categories: "", DesignerName: "", QAName: "", Page: "", ImgURL: ""
  });

  const handleInputs = (e) => {

    let name = e.target.name;
    let value = e.target.value;
    setUserInput({ ...userInput, [name]: value });
  }

  const submitSite = async (e) => {
    const {Project, Categories, DesignerName, QAName, Page, ImgURL}=userInput;
    e.preventDefault();
    const res = await fetch("https://adsweb-3f6d6-default-rtdb.firebaseio.com/websites.json",{
      method:"POST",
      headers:{
        "Content-Type":"application/json"
      },
      body:JSON.stringify({
        Project, Categories, DesignerName, QAName, Page, ImgURL
      })
    })
    setUserInput({Project: "", Categories: "", DesignerName: "", QAName: "", Page: "", ImgURL: ""});
    console.log("Huraahh... Web submitted successfully");
  }

  return (
    <><section id="addSite">
    <div className="container">
        <form action="" className="row" onSubmit={submitSite}>
            <div className="col-md-6">
                <label htmlFor="inputProject" className="form-label">Select Project Name</label>
                <select id="inputProject" name='Project' className="form-select" onChange={handleInputs}>
                  <option value="Telstra">Telstra</option>
                  <option value="1">1&1</option>
                  <option value="IOL">IOL</option>
                  <option value="APN Business">APN Business</option>
                  <option value="Telenet Business">Telenet Business</option>
                  <option value="FCR Media">FCR Media</option>
                </select>
            </div>
            <div className="col-md-6">
                <label htmlFor="projectCategories" className="form-label">Select Project Type</label>
                <select id="projectCategories" name='Categories' className="form-select" onChange={handleInputs}>
                  <option value="Basic">Basic</option>
                  <option value="Standard">Standard</option>
                  <option value="Advance">Advance</option>
                  <option value="Premium">Premium</option>
                </select>
            </div>
            <div className="col-md-2 gy-2">
                <label htmlFor="page" className="form-label">Pages</label>
                <input type="number" name='Page' min="1" className="form-control" onChange={handleInputs} id="pages" placeholder="Enter Page"></input>
              </div>
              <div className="col-md-5 gy-2">
                <label htmlFor="dName" className="form-label">Designer Name</label>
                <input type="text" name='DesignerName' className="form-control" onChange={handleInputs} id="pages" placeholder=""></input>
              </div>
              <div className="col-md-5 gy-2">
                <label htmlFor="qName" className="form-label">QA Name</label>
                <input type="text" name='QAName' className="form-control" onChange={handleInputs} id="pages" placeholder=""></input>
              </div>
              <div className="imgUrl gy-2">
                <label htmlFor="" className="form-label">Website Thumbnails Url</label>
                <input type="text" name='ImgURL' className="form-control" onChange={handleInputs} id="pages" placeholder=""></input>
              </div>
              <div className="col-12 gy-2">
                <button type="submit" className="btn btn-success">Submit</button>
              </div>
        </form>
    </div>
</section></>
  )
}

export default AddSlide